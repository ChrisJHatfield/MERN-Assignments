const ProductController = require('../controllers/controllers.product');

module.exports = function(app) {
    app.post('/api/product', ProductController.createProduct);
}