import React from 'react'
import ProductForm from '../components/ProductForm'

const Main = () => {

    return(
        <ProductForm />
    )
}

export default Main;