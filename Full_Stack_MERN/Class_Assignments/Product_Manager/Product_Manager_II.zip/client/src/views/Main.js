import React, {useState, useEffect} from 'react'
import ProductForm from '../components/ProductForm'
import axios from 'axios';
import ProductList from '../components/ProductList';

const Main = () => {

    const [products, setProducts] = useState([]);
    const [loaded, setLoaded] = useState(false);

    useEffect(() =>{
        axios.get('http://localhost:8000/api/product')
        .then(res => {
            setProducts(res.data)
            setLoaded(true);
        });
    }, [])

    return(
        <div className="main">
            <ProductForm />
            <hr/>
            {loaded && <ProductList products={products} />}
        </div>

    )
}

export default Main;