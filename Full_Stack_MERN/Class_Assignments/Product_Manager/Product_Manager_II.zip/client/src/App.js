import './App.css';
import React from 'react';
import { Router } from '@reach/router';
import Main from './views/Main';
import ProductDetails from './views/ProductDetails';

function App() {
  return (
    <div className="App">
      <Router>
        <Main path="/"/>
        <ProductDetails path="/:id" />
      </Router>
    </div>
  );
}

export default App;