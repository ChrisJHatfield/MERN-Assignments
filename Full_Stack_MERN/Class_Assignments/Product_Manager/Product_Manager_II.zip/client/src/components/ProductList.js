import React from 'react';
import { Link } from '@reach/router';

const ProductList = ({products}) => {

    return(
        <div className="all-products">
            <h1>All Products:</h1>
            {
                products.map((product, idx) => {
                    return <p key={idx}>
                        <Link to={"/" + product._id}>
                            {product.title}
                        </Link>
                    </p>
                })
            }
        </div>
    )
}

export default ProductList;