import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

const ProductDetails = (props) => {

    const [product, setProduct] = useState({});

    useEffect( () => {
        axios.get('http://localhost:8000/api/product/'+ props.id)
            .then(res => setProduct(res.data))
            .catch(err => console.log(err))
    }, [props.id])

    const deleteAProduct = (productId) => {
        axios.delete("http://localhost:8000/api/product/"+ productId)
            .then(res => {
                console.log(res);
                navigate('/');
            })
            
    }

    return(
        <div className="details">
            <h2>{product.title}</h2>
            <p>Price: ${product.price}</p>
            <p>Description: {product.description}</p>
            <button onClick={() => deleteAProduct(`${product._id}`)}>Delete</button>
        </div>
    )
}

export default ProductDetails;