import React from "react";

class HeaderTag extends React.Component {

    constructor(prop){
        super(prop);
    }

    render() {
        return (
            <h1 className="header">Hello Dojo!</h1>
        )
    }


}
export default HeaderTag;