import React from 'react';
import './SubContents.css';

class SubContents extends React.Component {
    constructor(props){
        super(props);
    };
    render() {
        return(
            <div className="subContents">
            </div>
        );
    }
}
export default SubContents;