import React from 'react';
import './Advertisement.css';

class Advertisement extends React.Component {
    constructor(props){
        super(props);
    };
    render() {
        return(
            <div className="advertisement">
            </div>
        );
    }
}
export default Advertisement;