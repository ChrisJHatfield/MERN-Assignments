import React from 'react';
import './Navigation.css';

class Navigation extends React.Component {
    constructor(props) {
        super(props);
    };
    render() {
        return(
            <div className="navigation">
            </div>
        );
    }
}
export default Navigation;