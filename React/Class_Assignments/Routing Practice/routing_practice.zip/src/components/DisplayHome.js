import React from 'react';

const DisplayHome = () => {

    return(
        <div>
            <p>Welcome</p>
        </div>
    )
}

export default DisplayHome;